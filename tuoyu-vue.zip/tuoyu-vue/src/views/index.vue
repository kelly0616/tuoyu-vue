<template>
  <div class="app-container home">

  </div>
</template>

<script>
export default {
  name: "Index",
  data() {
    return {

    };
  },
};
</script>

<style scoped lang="scss">

</style>

